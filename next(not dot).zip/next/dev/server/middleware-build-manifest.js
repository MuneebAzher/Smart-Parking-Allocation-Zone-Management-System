globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/6779f_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_4b892918._.js",
    "static/chunks/6779f_next_dist_compiled_react-dom_49f92f41._.js",
    "static/chunks/6779f_next_dist_compiled_react-server-dom-turbopack_42e89f9c._.js",
    "static/chunks/6779f_next_dist_compiled_next-devtools_index_1f44d4e5.js",
    "static/chunks/6779f_next_dist_compiled_56057027._.js",
    "static/chunks/6779f_next_dist_client_e430853c._.js",
    "static/chunks/6779f_next_dist_05d97c7b._.js",
    "static/chunks/6779f_@swc_helpers_cjs_4dbc059e._.js",
    "static/chunks/Desktop_dsa_project_v3_a0ff3932._.js",
    "static/chunks/turbopack-Desktop_dsa_project_v3_6b578164._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];