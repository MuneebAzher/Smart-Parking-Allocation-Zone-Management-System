(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_4b892918._.js",
  "static/chunks/6779f_next_dist_compiled_react-dom_49f92f41._.js",
  "static/chunks/6779f_next_dist_compiled_react-server-dom-turbopack_42e89f9c._.js",
  "static/chunks/6779f_next_dist_compiled_next-devtools_index_1f44d4e5.js",
  "static/chunks/6779f_next_dist_compiled_56057027._.js",
  "static/chunks/6779f_next_dist_client_e430853c._.js",
  "static/chunks/6779f_next_dist_05d97c7b._.js",
  "static/chunks/6779f_@swc_helpers_cjs_4dbc059e._.js"
],
    source: "entry"
});
