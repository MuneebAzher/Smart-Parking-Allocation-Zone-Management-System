(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_dsa_project_v3_c52ce5dd._.js",
  "static/chunks/6779f_c4366d31._.js"
],
    source: "dynamic"
});
