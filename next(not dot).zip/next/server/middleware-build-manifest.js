globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/7e2ba44ccd7a6437.js",
    "static/chunks/0a6ad4773d53ac22.js",
    "static/chunks/73b757a3a71820c4.js",
    "static/chunks/05d00cb2e7e62272.js",
    "static/chunks/turbopack-cb390ccd73624ece.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];