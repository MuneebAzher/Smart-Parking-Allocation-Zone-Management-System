module.exports=[301,(a,b,c)=>{"use strict";b.exports=a.r(52902).vendored["react-ssr"].ReactJsxRuntime},20195,(a,b,c)=>{"use strict";b.exports=a.r(52902).vendored["react-ssr"].ReactDOM}];

//# sourceMappingURL=6779f_next_dist_server_route-modules_app-page_vendored_ssr_4294863e._.js.map