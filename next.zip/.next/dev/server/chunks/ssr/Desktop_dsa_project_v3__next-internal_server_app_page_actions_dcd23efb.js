module.exports = [
"[project]/Desktop/dsa/project_v3/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_dsa_project_v3__next-internal_server_app_page_actions_dcd23efb.js.map